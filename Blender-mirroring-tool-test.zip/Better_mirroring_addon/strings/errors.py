errors = {
    "Message_no_objects_selected":"INFO: No objects selected."
}