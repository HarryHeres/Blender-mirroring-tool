descriptions = {
    "MirrorButton_bl_description":"Mirror selected object(s)",
    "MirrorMenu_suffix_description":"Suffix for newly mirrored model(s).\nCan be left empty"
}