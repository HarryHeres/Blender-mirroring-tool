ids = {
    "MirrorButton_bl_idname":"mirroring.flip_button",
    "MirrorMenu_bl_idname":"mirroring.mirror_menu"
}