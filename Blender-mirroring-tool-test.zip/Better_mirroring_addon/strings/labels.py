labels = {
    "MirrorButton_bl_label":"Mirror selected object(s)",
    "MirrorMenu_bl_label":"Object mirroring",
    
    "MirrorMenu_global_mirror_label":"Mirror Across Global Axes + Origin",
    "MirrorMenu_suffix_label":"Suffix"
}